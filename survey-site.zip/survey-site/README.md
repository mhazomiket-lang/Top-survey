# National Panel — Survey Landing Page

A clean, mobile-ready landing page for the US opinion survey campaign.

## File Structure

```
survey-site/
├── index.html        ← Main landing page
├── assets/
│   └── logo.svg      ← Brand logo (inline SVG)
└── README.md
```

## Deploying to GitHub Pages

1. Create a new GitHub repository (e.g. `survey-site`)
2. Upload all files keeping the folder structure intact
3. Go to **Settings → Pages**
4. Under **Source**, select `Deploy from a branch` → `main` → `/ (root)`
5. Click **Save** — your site will be live at:
   `https://<your-username>.github.io/survey-site/`

## Local Preview

Just open `index.html` in any browser — no build step needed.
